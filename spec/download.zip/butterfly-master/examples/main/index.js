define(['butterfly/container', 'view!mail/index.html'], function(Container, V){

	var v = new V();

	return Container;
});