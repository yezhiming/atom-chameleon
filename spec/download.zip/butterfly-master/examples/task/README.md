TaskQueue API demo
