define(['butterfly/view'], function(View){

	return View.extend({
		render: function(){
			this.el.innerHTML = 'asdfsfasdfasdsf';
		}
	});
});