tasks app demo

reference:
* http://www.slatestudio.com/blog/p/backbone-collection-with-pagination
* https://github.com/backbone-paginator/backbone.paginator#id3

how to run:
coffee server.coffee
